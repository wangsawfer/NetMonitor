@echo off
rem Launch the graphical front-end.
rem
rem The window is Python with tkinter, standard library only. The capture
rem engine is netmon.exe next to this file. The GUI asks for elevation itself,
rem so this wrapper only has to find a Python interpreter.
rem
rem Arguments are forwarded verbatim. For paths containing spaces it is easier
rem to start the GUI with no arguments and pick the target with the Browse
rem button, because cmd re-parses quoted arguments.
setlocal
cd /d "%~dp0"

set NETMON_PY=
where pythonw.exe >nul 2>&1 && set NETMON_PY=pythonw.exe
if not defined NETMON_PY (
    where py.exe >nul 2>&1 && set NETMON_PY=py.exe -w
)

if not defined NETMON_PY (
    echo.
    echo   Python 3 was not found on PATH.
    echo.
    echo   The graphical interface needs Python with tkinter. Install Python 3
    echo   from python.org and tick the box that adds it to PATH, or use the
    echo   headless launcher instead:  run-netmon.cmd --app "..."
    echo.
    pause
    exit /b 1
)

rem No start here: it re-parses the command line and shreds quoted arguments.
rem pythonw.exe has no console, so this call returns immediately anyway.
%NETMON_PY% "%~dp0gui\netmon_gui.py" %*
endlocal
