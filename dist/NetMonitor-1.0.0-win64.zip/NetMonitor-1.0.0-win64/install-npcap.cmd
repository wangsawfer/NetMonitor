@echo off
rem Install the Npcap packet capture driver, silently.
rem
rem NetMonitor's primary source (ETW) needs no driver; this is required only
rem for the packet-capture supplement that catches applications with their own
rem DNS resolver, and for TLS SNI recovery.
rem
rem The installer places the kernel driver in %SystemRoot%\System32\drivers --
rem Windows requires it to live there to load at all -- and the user-mode DLLs
rem in %SystemRoot%\System32. That is roughly 1.6 MB on the system drive and is
rem not configurable; see docs\MANUAL.md, "Disk layout".
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0'"
    exit /b
)

if not exist "%~dp0deps\npcap-1.79.exe" (
    echo ERROR: deps\npcap-1.79.exe not found.
    exit /b 1
)

echo Installing Npcap from deps\npcap-1.79.exe ...
"%~dp0deps\npcap-1.79.exe" /S /winpcap_mode=yes /loopback_support=yes /dot11_support=yes
if %errorlevel% neq 0 (
    echo Npcap installer exited with %errorlevel%
    exit /b %errorlevel%
)

sc query npcap | findstr /i "RUNNING" >nul
if %errorlevel% equ 0 (
    echo Npcap driver is running.
) else (
    echo Installer finished but the driver is not running.
    echo See %SystemRoot%\System32\Npcap\NPFInstall.log
)
endlocal
