@echo off
rem NetMonitor launcher.
rem
rem ETW trace sessions and the Npcap driver both require Administrator, so this
rem wrapper elevates. The monitor starts *before* the target application is
rem launched, which is what guarantees the first query is captured.
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0' -ArgumentList '%*'"
    exit /b
)

set NETMON_ARGS=%*
if "%NETMON_ARGS%"=="" (
    echo.
    echo   This build has no terminal interface. Use one of:
    echo.
    echo     run-netmon-gui.cmd                                     graphical window
    echo     run-netmon.cmd --app "C:\Path\To\App.exe"             headless, prints records
    echo     run-netmon.cmd --app "C:\Path\To\App.exe" --duration 30 --export out.csv
    echo.
    echo   Full documentation: docs\MANUAL.md
    echo.
    exit /b 2
)

rem Use an explicit path: cmd only searches the current directory when
rem NoDefaultCurrentDirectoryInExePath is unset, which hardened systems
rem routinely set.
"%~dp0netmon.exe" %NETMON_ARGS%
set RC=%errorlevel%
if %RC% neq 0 (
    echo.
    echo netmon exited with code %RC%
    pause
)
endlocal
